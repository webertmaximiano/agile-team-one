<div class="footer">

	<div class="copyright">

		<div class="container">

			<div class="row">

				<div class="col-md-12">

					<span><?php echo $titulo_rodape; ?> <br class="visible-xs visible-sm"/><?php echo date('Y'); ?> - Todos os direitos reservados</span>

				</div>

			</div>

		</div>

	</div>

</div>